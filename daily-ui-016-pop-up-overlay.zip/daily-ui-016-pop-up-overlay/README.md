# Daily UI #016 | Pop-up/Overlay

A Pen created on CodePen.

Original URL: [https://codepen.io/juliepark/pen/qKQzJL](https://codepen.io/juliepark/pen/qKQzJL).

This is a popup overlay design for your portfolio! Display your projects/work in detail with a click of a button. 
# Transitioning Between Variable Heights with CSS Tabs

A Pen created on CodePen.

Original URL: [https://codepen.io/alvarotrigo/pen/GRMbzBR](https://codepen.io/alvarotrigo/pen/GRMbzBR).


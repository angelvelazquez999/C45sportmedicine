# Pure CSS tab indicator animation

A Pen created on CodePen.

Original URL: [https://codepen.io/ceramicSoda/pen/WNgybXN](https://codepen.io/ceramicSoda/pen/WNgybXN).

Pure CSS tab animation with transitions